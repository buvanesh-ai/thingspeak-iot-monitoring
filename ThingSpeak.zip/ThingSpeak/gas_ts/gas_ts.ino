#include <ESP8266WiFi.h>;

#include <WiFiClient.h>;

#include <ThingSpeak.h>;

const char* ssid = "chase"; //Your Network SSID

const char* password = "123456789"; //Your Network Password

int val;

int Gas = A0; //Gas Sensor Pin Connected at A0 Pin



WiFiClient client;

unsigned long myChannelNumber =    3410370; //Your Channel Number (Without Brackets)

const char * myWriteAPIKey = "M08BQSBA1MRIEXIB"; //Your Write API Key

void setup()
{
Serial.begin(115200);

delay(10);

// Connect to WiFi network

WiFi.begin(ssid, password);

ThingSpeak.begin(client);
}
void loop()
{

val = analogRead(Gas); //Read Analog values and Store in val variable

Serial.println(val); //Print on Serial Monitor

delay(1000);

ThingSpeak.writeField(myChannelNumber, 1,val, myWriteAPIKey); //Update in ThingSpeak

delay(100);

}
