#include<ESP8266WiFi.h>;
#include<WiFiClient.h>;
#include<ThingSpeak.h>
#include <Adafruit_BMP280.h>
#include <Wire.h>
Adafruit_BMP280 bmp;


const char* ssid = "chase";
const char* password = "123456789";

WiFiClient client;

unsigned long mychannelnumber = 3415134;
const char * myWriteAPIKey = "GSECCDI9AWGXMV2K";


void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid,password);
  ThingSpeak.begin(client);
  if (!bmp.begin(0x76)) {
    Serial.println("Could not find BMP280 sensor!");
    while (1);
  }
}

void loop() {
  float temp = bmp.readTemperature();
  float pres = bmp.readPressure() / 100.0F; // hPa
  float alt  = bmp.readAltitude(1013.25); /* Adjusted to local forecast! */


  // Send data as CSV format
  Serial.print(temp);
  Serial.print(",");
  Serial.print(alt);
  Serial.print(",");
  Serial.println(pres);

  delay(1000); // every 5 sec

  ThingSpeak.writeField(mychannelnumber,1,temp,myWriteAPIKey);
  ThingSpeak.writeField(mychannelnumber,2,alt,myWriteAPIKey);
  ThingSpeak.writeField(mychannelnumber,3,pres,myWriteAPIKey);
  delay(100);
}
