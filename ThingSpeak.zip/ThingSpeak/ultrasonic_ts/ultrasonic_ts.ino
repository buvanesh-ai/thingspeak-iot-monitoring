#include <ESP8266WiFi.h>;
#include <WiFiClient.h>;
#include <ThingSpeak.h>;
#define trig D3 
#define echo D4
const char* ssid = "chase"; 
const char* password = "123456789";
WiFiClient client;
unsigned long myChannelNumber = 3410461; 
const char * myWriteAPIKey = "QSTS5YY4JUMTIO9S";

void setup(){
  pinMode(trig,OUTPUT);
  pinMode(echo,INPUT);
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  ThingSpeak.begin(client);
  delay(10);
}

void loop(){
  digitalWrite(trig,LOW);
  delayMicroseconds(2);
  digitalWrite(trig,HIGH);
  delayMicroseconds(10);
  digitalWrite(trig,LOW);
  long duration = pulseIn(echo,HIGH);
  float distance = duration * 0.034 /2;
  Serial.println(distance);
  ThingSpeak.writeField(myChannelNumber, 1,distance, myWriteAPIKey); //Update in ThingSpeak
  delay(1000); 
}
