#include<ESP8266WiFi.h>;
#include<WiFiClient.h>;
#include<ThingSpeak.h>

const char* ssid = "chase";
const char* password = "123456789";


WiFiClient client;

unsigned long mychannelnumber = 3410430;
const char * myWriteAPIKey = "9YFKHWVZC95KUS3E";

#include <DHT.h>
#define DHTPIN D2
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  delay(10);

  WiFi.begin(ssid,password);
  ThingSpeak.begin(client);
  dht.begin();
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  ThingSpeak.writeField(mychannelnumber,1,t,myWriteAPIKey);
  ThingSpeak.writeField(mychannelnumber,2,h,myWriteAPIKey);
  delay(100);

  if (isnan(h) || isnan(t)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  Serial.print("Humidity: ");
  Serial.print(h);
  Serial.print("%\t");

  Serial.print("Temperature: ");
  Serial.print(t);
  Serial.println(" C");

  delay(2000);
}
